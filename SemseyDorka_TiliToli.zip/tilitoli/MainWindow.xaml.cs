﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ttv
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int[] allas = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };
        int[] kesz = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };
        int lepesek = 0;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Button ezGomb = sender as Button;
            Button nullagomg = (Button)FindName("gomb0");
            var fTav = Math.Abs(ezGomb.Margin.Top - nullagomg.Margin.Top);
            var vTav = Math.Abs(ezGomb.Margin.Left - nullagomg.Margin.Left);

            int ezGombfelirat = Convert.ToInt32(ezGomb.Content);
            int ezGombIndex = Array.IndexOf(allas, ezGombfelirat);
            int nullaGombIndex = Array.IndexOf(allas, 0);
           
            if ((fTav == 200 && vTav == 0) || (vTav == 200 && fTav == 0))
            {
                var seged = ezGomb.Margin;
                ezGomb.Margin = nullagomg.Margin;
                nullagomg.Margin = seged;

                allas[nullaGombIndex] = allas[ezGombIndex];
                allas[ezGombIndex] = 0;
                lepesek++;
                lepesSzam.Text = lepesek + "";
                
                if (allas.SequenceEqual(kesz))
                {
                    lepesek = 0;
                    lepesSzam.Text = lepesek + "";
                    gomb0.Visibility = Visibility.Visible;
                    MessageBoxResult ablak = MessageBox.Show(" Sikerült kiarakni a krakós! Szertnéd folytatni a játékot?", "Gratulálok", MessageBoxButton.YesNo);
                    if (ablak == MessageBoxResult.No)
                    {
                        Application.Current.Shutdown();
                    }
                    else
                    {
                        gomb0.Visibility = Visibility.Hidden;
                        lepesek = 0;
                        lepesSzam.Text = lepesek + "";
                        keveres();

                    }
                }
            }
        }
        public void keveres()
        {
            lepesek = 0;
            lepesSzam.Text = lepesek + "";
            Random r = new Random();
            for (int i = 0; i < 100;)
            {
                gomb0.Visibility = Visibility.Hidden;
                int gomb = r.Next(1, 9);
                Convert.ToString(gomb);
                Button ezGomb = (Button)FindName("gomb" + gomb);
                Button NullGomb = (Button)FindName("gomb0");
                var fTav = Math.Abs(ezGomb.Margin.Top - NullGomb.Margin.Top);
                var vTav = Math.Abs(ezGomb.Margin.Left - NullGomb.Margin.Left);

                int ezGombfelirat = int.Parse(ezGomb.Content.ToString());
                int ezGombIndex = Array.IndexOf(allas, ezGombfelirat);
                int nullaGombIndex = Array.IndexOf(allas, 0);

                if ((fTav == 200 && vTav == 0) || (vTav == 200 && fTav == 0))
                {
                    var seged = ezGomb.Margin;
                    ezGomb.Margin = NullGomb.Margin;
                    NullGomb.Margin = seged;

                    allas[nullaGombIndex] = allas[ezGombIndex];
                    allas[ezGombIndex] = 0;
                    i++;
                }
            }
        }
        public void kever_Click(object sender, RoutedEventArgs e)
        {
            keveres();
            lepesek = 0;
        }
    }
}
    

